package com.example.apktienda1.Utils;

import android.graphics.Bitmap;
import android.widget.ImageView;

public interface OnLoadImg {
    public void onLoadImg(int index, Bitmap img);
}
