package com.example.apktienda1.Utils;

public interface OnLoadAllList {
    public void onLoadAllList();
}
