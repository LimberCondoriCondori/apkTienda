package com.example.apktienda1;

import android.graphics.Bitmap;

public class utils {
    public static String HOST = "http://192.168.100.20:8001";
    public static String REGISTER_USER = "/users/";
    public static String LOGIN = "/users/login";
    public static String PRODUCT="/product/";
    public static String UPLOAD_PRODUCT_IMG="/product/uploadImg";
    public static String DOWNLOAD_PRODUCT_IMG="/product/downloadImg";

    public static String TOKEN = "";
    public static String idUSer="";

    public static void SiguienteActividad(){

    }

}